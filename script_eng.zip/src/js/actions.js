function evolveChoose(params, context) {
    addAction({
        type: "evolve_choose",
        params: params,
    }, context);
}

function unitChoose(params, context){
    addAction({
        type: "unit_choose",
        params: params,
    }, context);
}

function goBack(params, context){
    addAction({
        type: "back",
        params: params
    }, context);
}

function modeChoose(params, context){
    addAction({
        type: "mode_choose",
        params: params
    }, context);
}

//function learnTranslate(params, context){
//    addAction({
//        type: "learn_translate",
//        params: params
//    }, context);
//}

function learnFlip(params, context){
    addAction({
        type: "learn_flip",
        params: params
    }, context);
}

function learnNext(params, context){
    addAction({
        type: "learn_next",
        params: params
    }, context);
}

function learnPrev(params, context){
    addAction({
        type: "learn_prev",
        params: params
    }, context);
}

